// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/page2/page2_widget.dart' show Page2Widget;
export '/pages/password/password_widget.dart' show PasswordWidget;
export '/pages/signup/signup_widget.dart' show SignupWidget;
export '/pages/current_page/current_page_widget.dart' show CurrentPageWidget;
export '/pages/aboutus/aboutus_widget.dart' show AboutusWidget;
export '/pages/current_page_copy/current_page_copy_widget.dart'
    show CurrentPageCopyWidget;
export '/pages/reservation/reservation_widget.dart' show ReservationWidget;
export '/pages/contact_us/contact_us_widget.dart' show ContactUsWidget;
export '/pages/signup_copy/signup_copy_widget.dart' show SignupCopyWidget;
export '/pages/reservation_copy/reservation_copy_widget.dart'
    show ReservationCopyWidget;
export '/pages/profile/profile_widget.dart' show ProfileWidget;
export '/pages/current_page_copy_copy/current_page_copy_copy_widget.dart'
    show CurrentPageCopyCopyWidget;
