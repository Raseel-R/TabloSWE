package com.mycompany.sweproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
